<html>
<head>
<title>CSS1</title>
<link rel="stylesheet" type="text/css" href="css/main.css">
<head>
<body>

	<div class="wrapper">
	<div class="top-bar  clearfix">
	<div class="top-bar-links">
		<ul>
		<li><a href="#">sign Up</a></li>
		<li><a href="#">Log In</a></li>
		<li><a href="#">RSS Feeds</a></li>
		<li><a href="#">Archived News</a></li>
		</ul>
	</div>
	<div class="site-search">
		<form method="get" action="index.html">
		<input type="text">
		<button type="submit"><img src="img/search1.png"></button>
		</form>
	</div>
	</div>	
	<header class="clearfix">
	<div class="logo">
		<h1>Systermatic</h1>
	</div>
	<div class="socialmedia">
	</div>
	</header>
	<h1>This is a heding : </h1>
	<nav>
	<ul>
	<li><a href="#">Home</a></li>
	<li><a href="#">About Us</a></li>
	<li><a href="#">Products</a></li>
	<li><a href="#">Contact Us</a></li>
	</ul>
	</nav>
	
	<div class="intro clearfix">
		<div class="introimage">
		<img src="img/background-with-white-squares_23-2147501484.jpg">
	</div>
	<div class="introtext">
	<h1>A Huge Title Heare</h1>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	<a href="#">Read More &raquo;</a>
	</div>
	</div>
	<div class="homecontent clearfix">
		<div class="home-col">
		<h2>A Little About Us </h2>
		<img src="img/background-with-white-squares_23-2147501484.jpg">
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur.</p> <p>Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		<a href="#">Read more abount us &raquo;</a>
		</div>
		<div class="home-col" alt="About Us">
		<h2>Some of Our Services</h2>
		</div>
		<div class="home-col">
		<h2>What our Clients Saye</h2>
		</div>
		</div>

</body>
</html>
